# AgroNova — Aegis Synthetic Demo Company

Synthetic agriculture / agritech company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-06-01, Maharashtra and Gujarat experience synthetic heat and rainfall stress.

Causal pattern:

Heat + rainfall stress
→ crop stress
→ yield ↓
→ irrigation / input requirements ↑
→ operating cost ↑
→ inventory / spoilage pressure
→ lower saleable output
→ revenue pressure
→ farm profitability risk ↑

`ground_truth.json` is evaluation metadata only and must never be supplied to the model as input.

All records are synthetic.
