# GreenGrid — Aegis Synthetic Demo Company

Synthetic energy and utilities company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-07-01, Mumbai and Thane experience synthetic extreme-weather pressure combined with elevated demand and stressed substations/transformers.

Causal pattern:

Weather stress + demand ↑
→ asset health / availability ↓
→ generation pressure
→ outage frequency + duration ↑
→ emergency maintenance ↑
→ operating costs ↑
→ customer complaints ↑
→ service and financial risk ↑

`ground_truth.json` is evaluation metadata only and must never be supplied to the model as input.
