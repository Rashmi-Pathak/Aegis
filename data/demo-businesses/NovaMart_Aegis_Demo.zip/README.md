# NovaMart — Aegis Synthetic Demo Company

Synthetic retail organization generated for testing the Aegis AI Business Risk & Decision Intelligence Platform.

## Dataset
- Customers: 25,000
- Products: 1,200
- Orders: 120,000
- Transactions: 130,000
- Inventory snapshots: 30,000
- Marketing records: 12,000
- Support tickets: 25,000
- Expenses: 20,000

## Hidden evaluation scenario
A synthetic supplier disruption begins on 2026-08-01. The model is NOT given the scenario label. Aegis should infer the emerging operational and financial risk from the raw business data.

## Intended pipeline
Raw files → schema detection → validation → cleaning → canonical business model → analytics → anomaly detection → forecasting → risk scoring → root-cause analysis → decision support.

Do not use `ground_truth.json` as model input. It exists only for offline evaluation.
