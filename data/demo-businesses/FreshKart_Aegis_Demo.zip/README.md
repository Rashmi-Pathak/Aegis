# FreshKart — Aegis Synthetic Demo Company

Synthetic grocery / quick-commerce company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-08-01, Mumbai and Pune experience a synthetic demand surge concentrated in perishable categories.

Causal pattern:

Demand ↑
→ Perishable inventory pressure ↑
→ Stockouts ↑
→ Delivery delays ↑
→ Freshness / quality issues ↑
→ Ratings ↓
→ Returns ↑
→ Waste + delivery cost ↑
→ Contribution-margin risk ↑

`ground_truth.json` is evaluation metadata only and must never be supplied to the model as input.

All records are synthetic.
