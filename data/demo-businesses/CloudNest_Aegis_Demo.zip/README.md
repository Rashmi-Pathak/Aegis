# CloudNest — Aegis Synthetic Demo Company

Synthetic B2B SaaS company generated for Aegis testing.

## Dataset
- customers.csv: 18,000 records
- subscriptions.csv: 22,000 records
- usage.csv: 180,000 records
- payments.csv: 80,000 records
- support.csv: 28,000 records
- marketing.csv: 10,000 records
- expenses.csv: 18,000 records
- employees.csv: 9,000 records

## Hidden evaluation scenario
Starting 2026-07-01, engagement deteriorates for higher-value customer cohorts. Aegis is not given this label and must identify the leading indicators of churn and recurring-revenue risk.

A secondary cloud-cost escalation begins 2026-06-01.

`ground_truth.json` is for offline evaluation only and must never be provided to the model as input.
