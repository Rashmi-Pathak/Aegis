# AutoCore — Aegis Synthetic Demo Company

Synthetic automotive manufacturing company for Aegis testing.

## Hidden scenario
Starting 2026-06-01, supplier SUP-00017 experiences a synthetic quality deterioration. Aegis is not given the supplier or root-cause label as model input.

The expected causal chain is:

Supplier quality deterioration
→ higher defect rate
→ procurement delays/rejections
→ component shortages
→ production downtime/output loss
→ vehicle order delays
→ increased operational cost

`ground_truth.json` is for offline evaluation only.
