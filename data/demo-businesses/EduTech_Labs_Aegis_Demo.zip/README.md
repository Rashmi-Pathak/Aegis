# EduTech Labs — Aegis Synthetic Demo Company

Synthetic education technology company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-07-01, Data Science and AI/ML programs experience synthetic course-experience and platform-support deterioration.

Causal pattern:

Engagement ↓
→ assessment performance ↓
→ support resolution time ↑
→ satisfaction ↓
→ course drop/pause ↑
→ payment failures / revenue at risk
→ support + cloud costs ↑

`ground_truth.json` is evaluation metadata only. It must never be supplied to the model as model input.
