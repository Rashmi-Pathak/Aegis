# StaySphere — Aegis Synthetic Demo Company

Synthetic hospitality and travel company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-07-01, Goa properties experience synthetic demand volatility and elevated cancellation pressure, followed by service-cost and guest-experience deterioration.

Causal pattern:

Demand volatility
→ cancellations / no-shows ↑
→ occupancy volatility
→ promotional efficiency ↓
→ service pressure
→ support demand ↑
→ guest satisfaction ↓
→ operating costs ↑
→ revenue / margin risk ↑

`ground_truth.json` is evaluation metadata only and must never be supplied to the model as input.

All records are synthetic.
