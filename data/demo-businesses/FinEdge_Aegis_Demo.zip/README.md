# FinEdge — Aegis Synthetic Demo Company

Synthetic fintech/lending company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-07-01, a subset of SME and self-employed borrowers experiences synthetic cash-flow pressure while newly originated loans for those segments carry higher borrowing costs.

Causal pattern:

Borrower cash-flow pressure
→ repayment delays ↑
→ default-risk events ↑
→ collections workload ↑
→ support demand + resolution time ↑
→ credit-risk exposure ↑
→ portfolio / liquidity risk ↑

`ground_truth.json` is evaluation metadata only and must never be supplied to the model as input.

All records are synthetic and contain no real financial or customer information.
