# BuildRight — Aegis Synthetic Demo Company

Synthetic construction company generated for Aegis testing.

## Hidden evaluation scenario
Starting 2026-05-01, Mumbai Commercial and Infrastructure projects experience synthetic material-supply and subcontractor pressure.

Expected causal pattern:

Supply pressure
→ procurement delays / material cost increase
→ milestone delays
→ equipment/logistics pressure
→ project expense increase
→ invoice/payment pressure
→ projected completion delay
→ budget overrun risk

`ground_truth.json` is for offline evaluation only and must never be supplied to the model as input.
