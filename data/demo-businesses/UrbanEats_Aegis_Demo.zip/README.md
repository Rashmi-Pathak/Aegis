# UrbanEats — Aegis Synthetic Demo Company

Synthetic multi-city food-delivery platform for Aegis testing.

## Hidden evaluation scenario
Starting 2026-08-01, Bengaluru experiences synthetic delivery-capacity and rider-cost pressure.

Expected causal pattern:

Delivery capacity pressure
→ delivery time increases
→ late deliveries increase
→ customer satisfaction declines
→ support volume/resolution time increases
→ rider/operations costs increase
→ contribution margin deteriorates

`ground_truth.json` is for offline evaluation only and must not be supplied to the model as input.
