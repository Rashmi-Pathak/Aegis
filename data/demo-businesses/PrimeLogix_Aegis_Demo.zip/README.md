# PrimeLogix — Aegis Synthetic Demo Company

Synthetic logistics and supply-chain company generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-08-01, West and North operations experience synthetic fuel-price pressure combined with route inefficiency and vehicle stress.

Causal pattern:

Fuel cost ↑
→ operating cost per shipment ↑
→ route / vehicle pressure
→ delivery duration ↑
→ delays + failures ↑
→ customer satisfaction ↓
→ support demand ↑
→ discounts / pricing pressure ↑
→ contribution-margin risk ↑

`ground_truth.json` is evaluation metadata only and must never be supplied to the model as input.
