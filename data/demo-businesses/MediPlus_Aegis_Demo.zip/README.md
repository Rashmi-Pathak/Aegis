# MediPlus — Aegis Synthetic Demo Company

Synthetic multi-facility healthcare operations company generated for Aegis testing.

## Hidden evaluation scenario
Starting 2026-07-01, a synthetic capacity bottleneck affects the Mumbai facility (MUM-01), particularly Emergency and General Medicine.

Expected causal pattern:

Capacity bottleneck
→ waiting time increases
→ patient complaints increase
→ service resolution worsens
→ inventory pressure increases
→ billing friction increases
→ operational costs rise

`ground_truth.json` is for offline evaluation only and must never be supplied to the model as input.

This dataset is entirely synthetic and contains no real patient information.
