# StyleSphere — Aegis Synthetic Demo Company

Synthetic fashion and e-commerce business generated for Aegis testing.

## Hidden evaluation scenario

Starting 2026-06-01, StyleSphere experiences a synthetic deterioration in paid-media efficiency while demand becomes concentrated in selected fashion categories.

Causal pattern:

Marketing spend ↑ + conversions ↓
→ ROAS deterioration
→ acquisition efficiency ↓
→ demand concentration
→ inventory imbalance / stockouts
→ returns and quality complaints ↑
→ customer sentiment ↓
→ profitability and risk deterioration

`ground_truth.json` is evaluation metadata only. It must never be provided as model input.
